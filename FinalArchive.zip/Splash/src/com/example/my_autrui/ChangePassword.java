package com.example.my_autrui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.parse.GetCallback;
import com.parse.ParseException;
import com.parse.ParseQuery;
import com.parse.ParseUser;

public class ChangePassword extends Activity {

	public void resetPassword() {
		final ParseUser currentUser = ParseUser.getCurrentUser();
		final Button resetPassword = (Button) findViewById(R.id.bResetPassword);
		final EditText emailBox = (EditText) findViewById(R.id.etEmailBox);
		ParseQuery<ParseUser> query = new ParseQuery<ParseUser>("User");
		query.whereEqualTo("email", emailBox.getText().toString());
		String myId = currentUser.getObjectId().toString();
		query.getInBackground(currentUser.getObjectId().toString(), new GetCallback<ParseUser>(){
			@Override
			public void done(ParseUser object, ParseException e) {
				// TODO Auto-generated method stub
				if (emailBox.toString() == currentUser.getEmail()) {
					Log.d("score", "The getFirst request failed.");
				} else {
					Log.d("score", "Retrieved the object.");
				}
			}
		});
//		try {
//			query.getFirst();
//			
//		} catch (ParseException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.changepassword);
		final Button resetPassword = (Button) findViewById(R.id.bResetPassword);

		resetPassword.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				resetPassword();
			}

		});

	}
}
